// Description: This is dog-image-gallery react app
// Name: Adewale Gbadamosi
// Date: July 25, 2024

import React, { useState, useEffect } from "react";
import BreedSelector from "./Components/BreedSelector";
import ImageGallery from "./Components/ImageGallery";
import "./App.css";
import Header from "./Components/Header";
import Footer from "./Components/Footer";

const App = () => {
  const [breed, setBreed] = useState("");
  const [numImages, setNumImages] = useState(1);
  const [images, setImages] = useState([]);

  const fetchImages = async (breed, numImages) => {
    try {
      const response = await fetch(
        `https://dog.ceo/api/breed/${breed}/images/random/${numImages}`
      );
      const data = await response.json();
      setImages(data.message);
    } catch (error) {
      console.error("Error fetching images:", error);
    }
  };

  useEffect(() => {
    if (breed) {
      fetchImages(breed, numImages);
    }
  }, [breed, numImages]);

  return (
    <div className="App">
      <Header />
      <BreedSelector
        breed={breed}
        setBreed={setBreed}
        numImages={numImages}
        setNumImages={setNumImages}
        fetchImages={fetchImages}
      />
      <ImageGallery images={images} />
      <Footer />
    </div>
  );
};

export default App;
