const Header = () => {
  const headerStyle = {
    backgroundColor: "blue",
    color: "white",
    fontSize: "30px",
    margin: "20px",
    border: "1px solid black",
    borderRadius: "5px",
  };

  return (
    <header>
      <h1 style={headerStyle}>Dog Image Gallery</h1>
    </header>
  );
};

export default Header;
