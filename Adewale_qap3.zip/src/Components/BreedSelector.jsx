import React, { useEffect, useState } from "react";

const BreedSelector = ({
  breed,
  setBreed,
  numImages,
  setNumImages,
  fetchImages,
}) => {
  const [breeds, setBreeds] = useState([]);

  useEffect(() => {
    const fetchBreeds = async () => {
      try {
        const response = await fetch("https://dog.ceo/api/breeds/list/all");
        const data = await response.json();
        setBreeds(Object.keys(data.message));
      } catch (error) {
        console.error("Error fetching breeds:", error);
      }
    };

    fetchBreeds();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchImages(breed, numImages);
  };

  return (
    <form onSubmit={handleSubmit}>
      <select value={breed} onChange={(e) => setBreed(e.target.value)}>
        <option value="">Select a breed</option>
        {breeds.map((b) => (
          <option key={b} value={b}>
            {b}
          </option>
        ))}
      </select>
      <input
        type="number"
        value={numImages}
        onChange={(e) => setNumImages(e.target.value)}
        min="1"
        max="100"
      />
      <button type="submit">Fetch Images</button>
    </form>
  );
};

export default BreedSelector;
