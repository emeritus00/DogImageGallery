import React from "react";
import "./ImageGallery.css";

const ImageGallery = ({ images }) => (
  <div className="image-gallery">
    {images.map((image, index) => (
      <img key={index} src={image} alt="dog" className="dog-image" />
    ))}
  </div>
);

export default ImageGallery;
