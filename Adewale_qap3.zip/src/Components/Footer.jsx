const Footer = () => {
  const date = new Date();
  const footerStyle = {
    backgroundColor: "blue",
    color: "white",
    fontSize: "18px",
    marginTop: "20px",
  };

  return (
    <footer style={footerStyle}>copyright &copy; {date.getFullYear()}</footer>
  );
};

export default Footer;
